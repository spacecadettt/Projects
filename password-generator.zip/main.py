import random
import string


def generate_password(length):

  if length <= 4:
    raise ValueError("O comprimento da senha deve ser de pelo menos 4")

  password = [
      random.choice(string.ascii_uppercase),
      random.choice(string.ascii_lowercase),
      random.choice(string.digits),
      random.choice(string.punctuation)
  ]

  if length > 4:
    characters = string.ascii_letters + string.digits + string.punctuation
    password += random.choices(characters, k=length-4)

  random.shuffle(password)

  return ''.join(password)


password_length = int(input("Insira o tamanho da senha: "))

generated_password = generate_password(password_length)

print("Senha Gerada:", generated_password)
